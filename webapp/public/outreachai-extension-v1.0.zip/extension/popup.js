const API_BASE = 'https://outreachai.in'

// Helper — safe getElementById
function el(id) { return document.getElementById(id) }

// ── On load: restore all saved settings ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  try {
    chrome.storage.local.get(['aiProvider', 'aiApiKey', 'dashToken', 'dashEmail', 'dashPlan'], (res) => {
      if (res.aiProvider && el('ai-provider')) el('ai-provider').value = res.aiProvider
      if (res.aiApiKey && el('ai-key'))        el('ai-key').value = res.aiApiKey
      if (res.dashToken) showConnected(res.dashEmail)
      else showLogin()
    })
  } catch(e) { showLogin() }

  // ── Dashboard connect ───────────────────────────────────────────────────────
  el('connect-btn')?.addEventListener('click', async () => {
    const email    = el('dash-email-input')?.value.trim()
    const password = el('dash-password-input')?.value
    const errEl    = el('login-error')
    const btn      = el('connect-btn')

    if (errEl) errEl.style.display = 'none'
    if (!email || !password) {
      if (errEl) { errEl.textContent = 'Enter email and password'; errEl.style.display = 'block' }
      return
    }

    if (btn) { btn.textContent = 'Connecting...'; btn.disabled = true }

    try {
      const res  = await fetch(`${API_BASE}/api/extension/auth`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json()

      if (!res.ok || !data.token) {
        if (errEl) { errEl.textContent = data.error || 'Invalid email or password'; errEl.style.display = 'block' }
        return
      }

      chrome.storage.local.set({ dashToken: data.token, dashEmail: email, dashPlan: data.plan || 'free', dashUrl: API_BASE })
      showConnected(email)
    } catch {
      if (errEl) { errEl.textContent = 'Could not reach dashboard — is the app running?'; errEl.style.display = 'block' }
    } finally {
      if (btn) { btn.textContent = 'Connect to Dashboard'; btn.disabled = false }
    }
  })

  // ── Disconnect ───────────────────────────────────────────────────────────────
  el('disconnect-btn')?.addEventListener('click', () => {
    chrome.storage.local.remove(['dashToken', 'dashEmail', 'dashPlan'])
    showLogin()
  })

  // ── AI API key save ──────────────────────────────────────────────────────────
  el('save-btn')?.addEventListener('click', () => {
    const provider = el('ai-provider')?.value
    const key      = el('ai-key')?.value.trim()
    if (!key) return
    chrome.storage.local.set({ aiProvider: provider, aiApiKey: key }, () => {
      if (el('saved')) { el('saved').style.display = 'block'; setTimeout(() => { el('saved').style.display = 'none' }, 2000) }
    })
  })
})

// (duplicate listeners removed — all handlers live inside DOMContentLoaded above)

// ── Helpers ───────────────────────────────────────────────────────────────────
function showConnected(email) {
  if (el('dash-connected')) el('dash-connected').style.display = 'block'
  if (el('dash-login'))     el('dash-login').style.display     = 'none'
  if (el('dash-email'))     el('dash-email').textContent       = email || ''

  const badge = el('dash-plan-badge')
  if (badge) {
    badge.textContent = 'Beta — Free'
    badge.className   = 'plan-badge plan-pro'
  }
  // All features unlocked during beta — no plan gate
  const upgradeMsg = el('ai-upgrade-msg')
  const aiControls = el('ai-controls')
  if (upgradeMsg) upgradeMsg.style.display = 'none'
  if (aiControls) aiControls.classList.remove('locked-overlay')
}

function showLogin() {
  if (el('dash-connected')) el('dash-connected').style.display = 'none'
  if (el('dash-login'))     el('dash-login').style.display     = 'block'
  // Still unlock AI even when not connected to dashboard
  const upgradeMsg = el('ai-upgrade-msg')
  const aiControls = el('ai-controls')
  if (upgradeMsg) upgradeMsg.style.display = 'none'
  if (aiControls) aiControls.classList.remove('locked-overlay')
}
