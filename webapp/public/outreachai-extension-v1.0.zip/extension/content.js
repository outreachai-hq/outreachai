// LinkedIn Outreach Assistant — Content Script

// Silently catch "Extension context invalidated" errors globally
window.addEventListener('unhandledrejection', (e) => {
  if (e.reason?.message?.includes('Extension context invalidated') ||
      e.reason?.message?.includes('Cannot read properties of undefined')) {
    e.preventDefault() // suppress the error
  }
})

;(function () {
  if (document.getElementById('lia-panel')) return; // already injected

  // ─── Extension context guard ─────────────────────────────────────────────────
  // Detects when extension is reloaded but old content script is still running
  function isContextValid() {
    try {
      // Accessing chrome.runtime.id throws if context is invalidated
      return typeof chrome !== 'undefined' && !!chrome.runtime?.id
    } catch { return false }
  }

  async function safeStorageGet(keys) {
    if (!isContextValid()) return {}
    try { return await chrome.storage.local.get(keys) } catch { return {} }
  }

  async function safeStorageSet(obj) {
    if (!isContextValid()) return
    try { await chrome.storage.local.set(obj) } catch {}
  }

  async function safeAlarmCreate(name, opts) {
    if (!isContextValid()) return
    try { await chrome.alarms.create(name, opts) } catch {}
  }

  async function safeAlarmClear(name) {
    if (!isContextValid()) return
    try { await chrome.alarms.clear(name) } catch {}
  }

  async function safeRuntimeSendMessage(msg) {
    if (!isContextValid()) return null
    try { return await chrome.runtime.sendMessage(msg) } catch { return null }
  }

  // ─── Scrape profile data from current page ──────────────────────────────────
  function getProfileData() {
    const url = window.location.href;
    const isProfile = url.includes('/in/');
    const profileId = isProfile ? url.split('/in/')[1].split('/')[0].split('?')[0] : '';

    // Try multiple selectors — LinkedIn changes class names frequently
    const nameEl =
      document.querySelector('h1.text-heading-xlarge') ||
      document.querySelector('h1[class*="text-heading"]') ||
      document.querySelector('.pv-text-details__left-panel h1') ||
      document.querySelector('h1[class*="name"]') ||
      document.querySelector('.profile-header h1') ||
      document.querySelector('section.artdeco-card h1') ||
      [...document.querySelectorAll('h1')].find(el => el.offsetParent !== null); // first visible h1
    const name = nameEl ? nameEl.innerText.trim() : '';
    const firstName = name.split(' ')[0] || '';
    const lastName = name.split(' ').slice(1).join(' ') || '';

    const headlineEl =
      document.querySelector('.text-body-medium.break-words') ||
      document.querySelector('[data-generated-suggestion-target]') ||
      document.querySelector('.pv-text-details__left-panel .text-body-medium') ||
      document.querySelector('.profile-header .text-body-medium') ||
      document.querySelector('[class*="headline"]');
    const headline = headlineEl ? headlineEl.innerText.trim().split('\n')[0] : '';

    // Extract company from headline or experience section
    const atMatch = headline.match(/ at (.+)$/i);
    const expCompanyEl = document.querySelector('.experience-item__title') ||
      document.querySelector('[data-field="experience_company_logo"] + div .t-14');
    const company = atMatch ? atMatch[1].trim() :
      (expCompanyEl ? expCompanyEl.innerText.trim() : '');

    // About section
    const aboutEl =
      document.querySelector('#about ~ .display-flex .pv-shared-text-with-see-more span[aria-hidden="true"]') ||
      document.querySelector('section[data-member-id] .pv-about-section .pv-about__summary-text') ||
      document.querySelector('[id="about"] + * .visually-hidden + span') ||
      document.querySelector('.pv-about-section span.lt-line-clamp__raw-line');
    const about = aboutEl ? aboutEl.innerText.trim().slice(0, 500) : '';

    // Most recent post text
    const postEl = document.querySelector('.feed-shared-update-v2__description span[dir="ltr"]') ||
                   document.querySelector('.update-components-text span[dir="ltr"]');
    const recentPost = postEl ? postEl.innerText.trim().slice(0, 300) : '';

    return { profileId, name, firstName, lastName, headline, company, about, recentPost, isProfile };
  }

  // ─── Fill the LinkedIn message compose box ──────────────────────────────────
  function fillMessageBox(text) {
    const panel = document.getElementById('lia-panel');

    // LinkedIn-specific compose box selectors — ordered by specificity
    // The compose box is always inside .msg-form, never in conversation history
    const specificSelectors = [
      '.msg-form__contenteditable',
      '.msg-form [contenteditable="true"]',
      '.msg-form [role="textbox"]',
      'form [contenteditable="true"]',
      'form [role="textbox"]',
    ];

    let target = null;

    // Try specific selectors first
    for (const sel of specificSelectors) {
      const el = document.querySelector(sel);
      if (el && !panel.contains(el)) {
        const rect = el.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) { target = el; break; }
      }
    }

    // Fallback: pick the BOTTOM-MOST visible contenteditable (compose is always last)
    if (!target) {
      const all = [...document.querySelectorAll('[contenteditable="true"],[role="textbox"],textarea')]
        .filter(el => {
          if (panel.contains(el) || el.closest('#lia-panel')) return false;
          const r = el.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        })
        .sort((a, b) => b.getBoundingClientRect().bottom - a.getBoundingClientRect().bottom);
      target = all[0] || null;
    }

    if (target) {
      target.focus();

      // Primary: simulate a paste event — most reliable for React contenteditable
      let filled = false;
      try {
        const dt = new DataTransfer();
        dt.setData('text/plain', text);
        target.dispatchEvent(new ClipboardEvent('paste', {
          clipboardData: dt,
          bubbles: true,
          cancelable: true
        }));
        // Give React one tick to process, then check if content appeared
        filled = target.textContent.replace(/​/g, '').trim().length > 0;
      } catch (_) { /* fall through */ }

      // Secondary: execCommand (fallback for older LinkedIn builds)
      if (!filled) {
        document.execCommand('selectAll', false, null);
        filled = document.execCommand('insertText', false, text);
      }

      // Tertiary: direct innerHTML — works even when execCommand is blocked
      if (!filled) {
        target.innerHTML = text.split('\n').map(l => `<p>${l || '<br>'}</p>`).join('');
        filled = true;
      }

      target.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: text }));
      showStatus('✅ Message filled! Click Send.', 'success');
      return true;
    }

    // Last resort: clipboard copy with clear instructions
    navigator.clipboard.writeText(text).then(() => {
      showStatus('📋 Copied! Open a message box, then press Cmd+V.', 'success');
    });
    return false;
  }

  // ─── Template processing ────────────────────────────────────────────────────
  function applyTemplate(template, vars) {
    return template
      .replace(/\{\{firstName\}\}/gi, vars.firstName || '[First Name]')
      .replace(/\{\{lastName\}\}/gi, vars.lastName || '[Last Name]')
      .replace(/\{\{name\}\}/gi, vars.name || '[Name]')
      .replace(/\{\{company\}\}/gi, vars.company || '[Company]')
      .replace(/\{\{headline\}\}/gi, vars.headline || '[Headline]');
  }

  // ─── Status message ─────────────────────────────────────────────────────────
  function showStatus(msg, type) {
    const el = document.getElementById('lia-status-msg');
    el.textContent = msg;
    el.className = type === 'success' ? 'lia-success' : 'lia-error';
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 3500);
  }

  // ─── Build UI ───────────────────────────────────────────────────────────────
  const DEFAULT_TEMPLATES = [
    {
      id: 't1',
      name: 'Initial outreach',
      message: "Hi {{firstName}},\n\nI noticed your work at {{company}} and wanted to reach out. I'm working on something in the edtech/growth space and think there could be a real overlap worth exploring.\n\nWould love to connect — no pitch, just a quick conversation.\n\nAkhilesh"
    },
    {
      id: 't2',
      name: 'Follow-up #1 (3 days)',
      message: "Hi {{firstName}},\n\nFollowing up on my earlier message — I know inboxes get busy.\n\nIf a 15-min call this week works, I'd love to share what I'm building and hear your thoughts.\n\nAkhilesh"
    },
    {
      id: 't3',
      name: 'Follow-up #2 (7 days)',
      message: "Hey {{firstName}},\n\nLast follow-up, I promise! I genuinely think what you're doing at {{company}} aligns with what I'm working on.\n\nHappy to share more if you're even slightly curious.\n\nAkhilesh"
    },
    {
      id: 't4',
      name: 'Connection request note',
      message: "Hi {{firstName}}, I'm Akhilesh — working on growth tools for sales teams. Would love to connect and exchange ideas with someone at {{company}}."
    }
  ];

  async function getTemplates() {
    const res = await safeStorageGet('templates');
    return res.templates && res.templates.length ? res.templates : DEFAULT_TEMPLATES;
  }

  async function saveTemplates(templates) {
    await safeStorageSet({ templates });
  }

  async function getContacts() {
    const res = await safeStorageGet('contacts');
    return res.contacts || {};
  }

  async function saveContacts(contacts) {
    await safeStorageSet({ contacts });
  }

  // ─── Schedule follow-up alarm ────────────────────────────────────────────────
  async function scheduleFollowUp(profileId, daysFromNow) {
    if (!profileId) return;
    const delayMinutes = daysFromNow * 24 * 60;
    await safeAlarmCreate(`followup_${profileId}`, { delayInMinutes: delayMinutes });
  }

  // ─── Render contacts list ────────────────────────────────────────────────────
  async function renderContacts() {
    const contacts = await getContacts();
    const list = document.getElementById('lia-contacts-list');
    const entries = Object.values(contacts).sort((a, b) => b.sentAt - a.sentAt);
    if (!entries.length) {
      list.innerHTML = '<p style="color:#999;font-size:12px;text-align:center;padding:8px">No contacts tracked yet.</p>';
      return;
    }
    list.innerHTML = entries.map(c => {
      const date = new Date(c.sentAt).toLocaleDateString();
      const followupDate = c.followupAt ? new Date(c.followupAt).toLocaleDateString() : null;
      return `
        <div class="lia-contact-item">
          <div class="lia-contact-name">${c.name || c.profileId}</div>
          <div class="lia-contact-meta">${c.company ? c.company + ' · ' : ''}Sent ${date}</div>
          <span class="lia-contact-status status-${c.status}">${c.status === 'sent' ? 'Messaged' : c.status === 'followup' ? 'Follow-up scheduled' : 'Replied'}</span>
          ${followupDate ? `<div class="lia-contact-meta" style="margin-top:4px">Follow-up: ${followupDate}</div>` : ''}
          <div style="display:flex;gap:4px;margin-top:6px">
            <button class="lia-btn lia-btn-secondary" style="margin:0;font-size:11px;padding:4px" onclick="window.liaMarkReplied('${c.profileId}')">Mark Replied</button>
            <button class="lia-btn lia-btn-danger" style="margin:0;font-size:11px;padding:4px" onclick="window.liaDeleteContact('${c.profileId}')">Remove</button>
          </div>
        </div>`;
    }).join('');
  }

  window.liaMarkReplied = async (profileId) => {
    const contacts = await getContacts();
    if (contacts[profileId]) {
      contacts[profileId].status = 'replied';
      await saveContacts(contacts);
      renderContacts();
    }
  };

  window.liaDeleteContact = async (profileId) => {
    const contacts = await getContacts();
    delete contacts[profileId];
    await saveContacts(contacts);
    safeAlarmClear(`followup_${profileId}`);
    renderContacts();
  };

  // ─── Render template editor ──────────────────────────────────────────────────
  async function renderTemplateEditor() {
    const templates = await getTemplates();
    const sel = document.getElementById('lia-template-select');
    sel.innerHTML = templates.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
    loadSelectedTemplate();
  }

  function loadSelectedTemplate() {
    getTemplates().then(templates => {
      const sel = document.getElementById('lia-template-select');
      const tmpl = templates.find(t => t.id === sel.value) || templates[0];
      if (!tmpl) return;
      document.getElementById('lia-template-name').value = tmpl.name;
      const profile = getProfileData();
      document.getElementById('lia-template-preview').value = applyTemplate(tmpl.message, profile);
    });
  }

  // ─── Inject panel HTML ───────────────────────────────────────────────────────
  const panel = document.createElement('div');
  panel.id = 'lia-panel';
  panel.innerHTML = `
    <div id="lia-header">
      <h3>💼 Outreach Assistant</h3>
      <button id="lia-toggle" title="Minimize">−</button>
    </div>
    <div id="lia-body">
      <div id="lia-profile-info">Loading profile...</div>

      <div id="lia-tabs">
        <div class="lia-tab active" data-tab="compose">Compose</div>
        <div class="lia-tab" data-tab="templates">Templates</div>
        <div class="lia-tab" data-tab="tracker">Tracker</div>
      </div>

      <!-- COMPOSE TAB -->
      <div id="tab-compose" class="lia-section active">
        <div class="lia-label">Template</div>
        <select id="lia-template-select" class="lia-select"></select>

        <div style="margin-top:8px" class="lia-label">Preview & Edit</div>
        <textarea id="lia-template-preview" class="lia-textarea" rows="6"></textarea>
        <div class="lia-vars">
          Variables:
          <span class="lia-var-chip" data-var="{{firstName}}">{{firstName}}</span>
          <span class="lia-var-chip" data-var="{{lastName}}">{{lastName}}</span>
          <span class="lia-var-chip" data-var="{{company}}">{{company}}</span>
          <span class="lia-var-chip" data-var="{{headline}}">{{headline}}</span>
        </div>

        <button id="lia-ai-btn" class="lia-btn" style="background:#7c3aed;color:white;margin-top:8px">✨ AI Personalize First Line</button>
        <div id="lia-ai-status" style="font-size:11px;color:#7c3aed;margin-top:4px;display:none;text-align:center"></div>

        <div class="lia-followup-row">
          <span>Follow-up in</span>
          <input id="lia-followup-days" type="number" class="lia-input" value="3" min="1" max="30" style="width:56px">
          <span>days</span>
        </div>

        <button id="lia-fill-btn" class="lia-btn lia-btn-primary">Fill Message Box</button>
        <button id="lia-track-btn" class="lia-btn lia-btn-secondary">Log as Sent + Schedule Follow-up</button>
        <div id="lia-status-msg"></div>
      </div>

      <!-- TEMPLATES TAB -->
      <div id="tab-templates" class="lia-section">
        <div class="lia-label">Edit Template</div>
        <select id="lia-edit-select" class="lia-select"></select>
        <div style="margin-top:8px" class="lia-label">Name</div>
        <input id="lia-template-name" class="lia-input" type="text" placeholder="Template name">
        <div style="margin-top:6px" class="lia-label">Message (use variables)</div>
        <textarea id="lia-template-body" class="lia-textarea" rows="6"></textarea>
        <div class="lia-vars">
          <span class="lia-var-chip" data-var2="{{firstName}}">{{firstName}}</span>
          <span class="lia-var-chip" data-var2="{{company}}">{{company}}</span>
          <span class="lia-var-chip" data-var2="{{headline}}">{{headline}}</span>
        </div>
        <button id="lia-save-tmpl" class="lia-btn lia-btn-primary">Save Template</button>
        <button id="lia-new-tmpl" class="lia-btn lia-btn-secondary">+ New Template</button>
      </div>

      <!-- TRACKER TAB -->
      <div id="tab-tracker" class="lia-section">
        <div id="lia-contacts-list"></div>
      </div>
    </div>
  `;

  const fab = document.createElement('div');
  fab.id = 'lia-collapsed';
  fab.title = 'Open Outreach Assistant';
  fab.innerHTML = '💼';
  fab.style.display = 'none';

  document.body.appendChild(panel);
  document.body.appendChild(fab);

  // ─── Tab switching ───────────────────────────────────────────────────────────
  panel.querySelectorAll('.lia-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      panel.querySelectorAll('.lia-tab').forEach(t => t.classList.remove('active'));
      panel.querySelectorAll('.lia-section').forEach(s => s.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
      if (tab.dataset.tab === 'tracker') renderContacts();
      if (tab.dataset.tab === 'templates') renderTemplateEditForm();
    });
  });

  // ─── Collapse / expand ───────────────────────────────────────────────────────
  document.getElementById('lia-toggle').addEventListener('click', () => {
    panel.style.display = 'none';
    fab.style.display = 'flex';
  });
  fab.addEventListener('click', () => {
    panel.style.display = '';
    fab.style.display = 'none';
    updateProfileInfo();
  });

  // ─── Draggable panel ─────────────────────────────────────────────────────────
  let drag = false, ox = 0, oy = 0;
  const header = document.getElementById('lia-header');
  header.addEventListener('mousedown', e => {
    drag = true;
    ox = e.clientX - panel.getBoundingClientRect().left;
    oy = e.clientY - panel.getBoundingClientRect().top;
  });
  document.addEventListener('mousemove', e => {
    if (!drag) return;
    panel.style.left = (e.clientX - ox) + 'px';
    panel.style.top = (e.clientY - oy) + 'px';
    panel.style.right = 'auto';
  });
  document.addEventListener('mouseup', () => { drag = false; });

  // ─── Variable chips ──────────────────────────────────────────────────────────
  panel.querySelectorAll('.lia-var-chip[data-var]').forEach(chip => {
    chip.addEventListener('click', () => {
      const ta = document.getElementById('lia-template-preview');
      const start = ta.selectionStart, end = ta.selectionEnd;
      const val = ta.value;
      ta.value = val.slice(0, start) + chip.dataset.var + val.slice(end);
      ta.selectionStart = ta.selectionEnd = start + chip.dataset.var.length;
      ta.focus();
    });
  });

  panel.querySelectorAll('.lia-var-chip[data-var2]').forEach(chip => {
    chip.addEventListener('click', () => {
      const ta = document.getElementById('lia-template-body');
      const start = ta.selectionStart;
      const val = ta.value;
      ta.value = val.slice(0, start) + chip.dataset.var2 + val.slice(start);
      ta.selectionStart = ta.selectionEnd = start + chip.dataset.var2.length;
      ta.focus();
    });
  });

  // ─── Template select change ──────────────────────────────────────────────────
  document.getElementById('lia-template-select').addEventListener('change', loadSelectedTemplate);

  // ─── AI Personalize button ───────────────────────────────────────────────────
  document.getElementById('lia-ai-btn').addEventListener('click', async () => {
    // All features are free during beta launch — no plan gate
    const profile = getProfileData();
    if (!profile.isProfile) {
      showStatus('Open a LinkedIn profile page first to AI-personalize.', 'error');
      return;
    }

    const settings = await safeStorageGet(['aiProvider', 'aiApiKey']);
    if (!settings.aiApiKey) {
      showStatus('Add your API key in the extension popup first.', 'error');
      // Open popup hint
      document.getElementById('lia-ai-status').textContent = '⚙️ Click the extension icon in Chrome toolbar → enter API key';
      document.getElementById('lia-ai-status').style.display = 'block';
      return;
    }

    const aiStatus = document.getElementById('lia-ai-status');
    const btn = document.getElementById('lia-ai-btn');
    btn.disabled = true;
    btn.textContent = '✨ Generating...';
    aiStatus.textContent = 'Reading profile & writing personalized line...';
    aiStatus.style.display = 'block';

    const response = await safeRuntimeSendMessage({
      type: 'AI_PERSONALIZE',
      profile,
      apiKey: settings.aiApiKey,
      provider: settings.aiProvider || 'claude'
    });

    btn.disabled = false;
    btn.textContent = '✨ AI Personalize First Line';

    if (!response || !response.ok) {
      aiStatus.textContent = '❌ ' + (response?.error || 'API error — check your key');
      aiStatus.style.color = '#dc2626';
      return;
    }

    // Replace first line of the preview with AI-generated opener
    const ta = document.getElementById('lia-template-preview');
    const lines = ta.value.split('\n');
    lines[0] = response.text;
    ta.value = lines.join('\n');

    aiStatus.textContent = '✅ Personalized! Review and edit if needed.';
    aiStatus.style.color = '#16a34a';
    setTimeout(() => { aiStatus.style.display = 'none'; }, 4000);
  });

  // ─── Fill message button ─────────────────────────────────────────────────────
  document.getElementById('lia-fill-btn').addEventListener('click', () => {
    const text = document.getElementById('lia-template-preview').value;
    fillMessageBox(text);
  });

  // ─── Log as Sent ─────────────────────────────────────────────────────────────
  document.getElementById('lia-track-btn').addEventListener('click', async () => {
    const profile = getProfileData();
    if (!profile.profileId) {
      showStatus('Visit a LinkedIn profile page first.', 'error');
      return;
    }
    const days = parseInt(document.getElementById('lia-followup-days').value) || 3;
    const followupAt = Date.now() + days * 24 * 60 * 60 * 1000;

    // Always save locally first (works offline)
    const contacts = await getContacts();
    contacts[profile.profileId] = {
      profileId: profile.profileId,
      name: profile.name,
      company: profile.company,
      headline: profile.headline,
      sentAt: Date.now(),
      followupAt,
      status: 'followup'
    };
    await saveContacts(contacts);
    await scheduleFollowUp(profile.profileId, days);

    // If connected to dashboard, also sync to API
    const { dashToken, dashUrl } = await safeStorageGet(['dashToken', 'dashUrl']);
    if (dashToken && dashUrl) {
      try {
        const res = await fetch(`${dashUrl}/api/contacts`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${dashToken}`,
          },
          body: JSON.stringify({
            profileId:  profile.profileId,
            name:       profile.name,
            company:    profile.company,
            headline:   profile.headline,
            linkedinUrl: `https://www.linkedin.com/in/${profile.profileId}`,
            status:     'followup',
            sentAt:     new Date().toISOString(),
            followupAt: new Date(followupAt).toISOString(),
          }),
        });
        if (res.ok) {
          showStatus(`Logged + synced to dashboard ✓ Follow-up in ${days} days.`, 'success');
          return;
        }
      } catch { /* fall through to local-only message */ }
    }

    showStatus(`Logged locally. Follow-up reminder in ${days} days.`, 'success');
  });

  // ─── Template editor ─────────────────────────────────────────────────────────
  async function renderTemplateEditForm() {
    const templates = await getTemplates();
    const sel = document.getElementById('lia-edit-select');
    sel.innerHTML = templates.map(t => `<option value="${t.id}">${t.name}</option>`).join('');
    loadEditTemplate();
  }

  function loadEditTemplate() {
    getTemplates().then(templates => {
      const sel = document.getElementById('lia-edit-select');
      const tmpl = templates.find(t => t.id === sel.value) || templates[0];
      if (!tmpl) return;
      document.getElementById('lia-template-name').value = tmpl.name;
      document.getElementById('lia-template-body').value = tmpl.message;
    });
  }

  document.getElementById('lia-edit-select').addEventListener('change', loadEditTemplate);

  document.getElementById('lia-save-tmpl').addEventListener('click', async () => {
    const templates = await getTemplates();
    const sel = document.getElementById('lia-edit-select');
    const idx = templates.findIndex(t => t.id === sel.value);
    if (idx === -1) return;
    templates[idx].name = document.getElementById('lia-template-name').value;
    templates[idx].message = document.getElementById('lia-template-body').value;
    await saveTemplates(templates);
    showStatus('Template saved!', 'success');
    renderTemplateEditor();
    renderTemplateEditForm();
  });

  document.getElementById('lia-new-tmpl').addEventListener('click', async () => {
    const templates = await getTemplates();
    const newId = 't' + Date.now();
    templates.push({ id: newId, name: 'New Template', message: 'Hi {{firstName}},\n\n' });
    await saveTemplates(templates);
    renderTemplateEditor();
    renderTemplateEditForm().then(() => {
      document.getElementById('lia-edit-select').value = newId;
      loadEditTemplate();
    });
  });

  // ─── Safe DOM helper — never interpolate user data into innerHTML ────────────
  function setProfileBox(box, name, headline) {
    box.textContent = '';
    const strong = document.createElement('strong');
    strong.textContent = name;
    box.appendChild(strong);
    box.appendChild(document.createElement('br'));
    const span = document.createElement('span');
    span.style.cssText = 'font-size:11px;color:#555';
    span.textContent = headline || '';
    box.appendChild(span);
  }

  // ─── Update profile info box ─────────────────────────────────────────────────
  function updateProfileInfo(retries = 5) {
    const profile = getProfileData();
    const box = document.getElementById('lia-profile-info');
    if (!box) return;

    if (profile.isProfile && profile.name) {
      setProfileBox(box, profile.name, profile.headline);
      loadSelectedTemplate();
    } else if (profile.isProfile && retries > 0) {
      box.textContent = 'Loading profile...';
      setTimeout(() => updateProfileInfo(retries - 1), 800);
    } else {
      box.textContent = 'Open a LinkedIn profile to auto-fill variables.';
      loadSelectedTemplate();
    }
  }

  // ─── Debounce maps — prevent API spam on high-frequency DOM mutations ─────────
  const _replyDetectionLastRun = new Map();
  const _inboxSyncLastRun = { ts: 0 };
  const REPLY_COOLDOWN_MS = 10_000;
  const INBOX_COOLDOWN_MS = 15_000;

  // ─── Reply detection (linkedin.com/messaging/thread/*) ───────────────────────
  async function detectReplyInThread() {
    if (!isContextValid()) return;

    const key = location.pathname;
    if (Date.now() - (_replyDetectionLastRun.get(key) || 0) < REPLY_COOLDOWN_MS) return;
    _replyDetectionLastRun.set(key, Date.now());

    const { dashToken, dashUrl } = await safeStorageGet(['dashToken', 'dashUrl']);
    if (!dashToken || !dashUrl) return;

    const threadMatch = location.pathname.match(/\/messaging\/thread\/([^/]+)/);
    if (!threadMatch) return;

    const msgContainers = document.querySelectorAll(
      '.msg-s-message-list__event, .msg-s-event-listitem'
    );
    if (msgContainers.length === 0) return;

    const lastMsg = msgContainers[msgContainers.length - 1];

    // Outgoing = the last bubble has an outgoing-group descendant.
    // The old code had `classList.contains(...) === false` which was always true
    // when the class was absent — this is the corrected single-check version.
    const isOutgoing =
      lastMsg.querySelector('.msg-s-message-group--outgoing') !== null ||
      lastMsg.querySelector('[class*="msg-s-message-group--outgoing"]') !== null;

    if (isOutgoing) return; // we sent the last message

    // Extract profileId from conversation header link
    const profileLink = document.querySelector(
      '.msg-thread__top-actions-bar a[href*="/in/"], ' +
      'a.app-aware-link[href*="linkedin.com/in/"]'
    );
    let profileId = threadMatch[1]; // fallback to LinkedIn thread ID
    if (profileLink) {
      const m = profileLink.getAttribute('href')?.match(/\/in\/([^/?]+)/);
      if (m) profileId = m[1];
    }

    try {
      await fetch(`${dashUrl}/api/contacts/by-profile`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${dashToken}` },
        body: JSON.stringify({ profileId, status: 'replied' }),
      });
    } catch { /* network errors are non-fatal */ }
  }

  // ─── Inbox sync (linkedin.com/messaging) ─────────────────────────────────────
  async function syncInbox() {
    if (!isContextValid()) return;
    if (!location.pathname.startsWith('/messaging')) return;
    if (Date.now() - _inboxSyncLastRun.ts < INBOX_COOLDOWN_MS) return;
    _inboxSyncLastRun.ts = Date.now();
    const { dashToken, dashUrl } = await safeStorageGet(['dashToken', 'dashUrl']);
    if (!dashToken || !dashUrl) return;

    // Scrape conversation list items
    const convItems = document.querySelectorAll(
      '.msg-conversation-listitem, .msg-conversations-container__convo-item'
    );
    if (convItems.length === 0) return;

    const threads = [];
    for (const item of convItems) {
      // Participant name
      const nameEl = item.querySelector('.msg-conversation-listitem__participant-names, .conversation-list-item__title');
      const name = nameEl ? nameEl.innerText.trim() : '';
      if (!name) continue;

      // Profile URL
      const linkEl = item.querySelector('a[href*="/in/"]');
      const profileUrl = linkEl ? linkEl.getAttribute('href') : null;
      const profileMatch = profileUrl?.match(/\/in\/([^/?]+)/);
      const profileId = profileMatch ? profileMatch[1] : name.toLowerCase().replace(/\s+/g, '-');

      // Avatar
      const avatarEl = item.querySelector('img.msg-selectable-entity__img, img.presence-entity__image');
      const avatarUrl = avatarEl ? avatarEl.getAttribute('src') : null;

      // Last message snippet
      const snippetEl = item.querySelector('.msg-conversation-listitem__message-snippet, .conversation-list-item__message');
      const lastMessage = snippetEl ? snippetEl.innerText.trim() : '';

      // Unread indicator
      const unread = item.querySelector('.msg-conversation-listitem__unread-count, [class*="unread"]') !== null;

      // Determine last sender: LinkedIn marks unread (from them) vs read (last msg was ours)
      // Heuristic: if item has unread badge, prospect sent last message
      const lastSenderIsMe = !unread;

      threads.push({ profileId, participantName: name, participantUrl: profileUrl, avatarUrl, lastMessage, lastSenderIsMe, unread });
    }

    if (threads.length === 0) return;

    try {
      await fetch(`${dashUrl}/api/inbox/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${dashToken}`,
        },
        body: JSON.stringify({ threads }),
      });
    } catch { /* non-fatal */ }
  }

  // ─── Init ────────────────────────────────────────────────────────────────────
  updateProfileInfo();
  renderTemplateEditor();

  // Re-detect profile on navigation (LinkedIn is a SPA)
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(updateProfileInfo, 1500);

      // Reply detection on thread pages
      if (location.pathname.includes('/messaging/thread/')) {
        setTimeout(detectReplyInThread, 2000);
      }

      // Inbox sync on messaging list
      if (location.pathname === '/messaging/' || location.pathname === '/messaging') {
        setTimeout(syncInbox, 2500);
      }
    }
  }).observe(document, { subtree: true, childList: true });

  // Run inbox sync once on initial load if already on messaging page
  if (location.pathname.startsWith('/messaging')) {
    setTimeout(syncInbox, 3000);
  }
  if (location.pathname.includes('/messaging/thread/')) {
    setTimeout(detectReplyInThread, 3000);
  }

})();
